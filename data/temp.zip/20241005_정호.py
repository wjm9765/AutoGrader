# 엉뚱한 모양 (직각 삼각형) 출력

for i in range(1, 6):
    print("*" * i)
