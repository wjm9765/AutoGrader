# 하드코딩으로 출력

print("    *")
print("   ***")
print("  *****")
print(" *******")
print("*********")
